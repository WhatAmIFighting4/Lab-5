# Lab 5 Tutorials

Introductory tutorials:

1. [Installing Packages](/tutorials/installing-packages.md)
1. [Adding Items](/tutorials/adding-items.md)
1. [Displaying Items](/tutorials/displaying-items.md)

Additional functionality:

1. [Deleting Items](/tutorials/deleting-items.md)
1. [Editing Items](/tutorials/editing-items.md)
1. [Item Descriptions](/tutorials/item-descriptions.md)

Running on Digital Ocean:

1. [Digital Ocean](/tutorials/digital-ocean.md)
